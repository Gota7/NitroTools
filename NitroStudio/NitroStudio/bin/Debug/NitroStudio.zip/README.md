# Nitro Studio 
An Editor For Nitro Sound Data (*.sdat) 
 
## Features 
* Packing, extracting, saving SDATS. 
* Ability to add files or nodes. 
* Ability to remove files or nodes. 
* Edit string names or info of nodes. 
* Edit SWARs.
* Edit SBNKs.
* View hex data of un-openable files. 
 
## Known Bugs 
* Cannot edit placeholders. 
* Cannot edit nodes that have a fileID out of index. 
 
## Credits 
Given in the about tab of the program. 